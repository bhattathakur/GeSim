# Run a batch of runs. (see README)
# Author: Raymond Tsang, rhmtsang@gmail.com

# number of simultaneous jobs
simult=$7

pushd /usr/local/geant4.9.6.p02/bin/; . geant4.sh; popd;
. /usr/local/root_v5.34.07/bin/thisroot.sh

if [[ -z $4 ]]; then
  echo "$0 <run prefix> <detector number (2,3,4)> <source type, e.g. Co60> <source position (1-3)> <number of events> <number of simult. jobs>"
  exit
fi

pushd /home/raymond/Projects/GeSim
if [[ ! -e nums/num-$1.txt ]]; then
 echo "1" > nums/num-$1.txt
fi
num=`awk '{print $1}' nums/num-$1.txt`
for i in `seq ${num} $((num+simult-1))`; do
  padded=`echo 000$i | tail -c 4`
  runname="$1_Ge$2-$3-${4}_${5}-${padded}"
  #echo "nohup ./run.sh $runname $2 $3 $4 $5 > ${runname}.out"
  nohup ./run.sh $runname $2 $3 $4 $5 $6 > ${runname}.out 2>&1 &
  echo $! > ${runname}.pid
done
echo $((num+simult)) > nums/num-$1.txt
popd
