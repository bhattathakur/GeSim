# Run a run. (See README)
# Author: Raymond Tsang, rhmtsang@gmail.com

# Determine source type and position 
echo "$1 start time: `date`"
# Seed
seed=`date +%N`

inputsourcetype=`echo $4 | awk -F_ '{print $1}'`
#echo $inputsourcetype

case "$inputsourcetype" in
"1")
  srctype='Circle'
  srcradius='2.5'
  srcori=`echo $4 | awk -F_ '{print $2}'`
  if [[ "$srcori" == "Down" ]]; then
    if [[ "$2" -eq "2" ]]; then
      srccenter="-21.975 -139.7 -148.82"
    elif [[ "$2" -eq "3" ]]; then 
      #srccenter="-8.875 -139.7 -148.82"
      srccenter="-8.875 -138.113 -147.232"
    elif [[ "$2" -eq "4" ]]; then 
      srccenter="-8.875 -138.113 -147.232"
    fi
  elif  [[ "$srcori" == "Up" ]]; then
    if [[ "$2" -eq "2" ]]; then
      srccenter="-21.975 -139.7 -149.63"
    elif [[ "$2" -eq "3" ]]; then 
      #srccenter="-8.875 -139.7 -146.45"  # wrong source geom, wrong chamber size
      #srccenter="-8.875 -139.7 -149.63"  # wrong chamber size 
      srccenter="-8.875 -138.113 -148.042"
    elif [[ "$2" -eq "4" ]]; then 
      srccenter="-8.875 -138.113 -148.042"
    fi
  fi
  ;;
"2")
  srctype='Circle'
  srcradius='2.5'
  srcori=`echo $4 | awk -F_ '{print $2}'`
  if [[ "$srcori" == "Down" ]]; then
    if [[ "$2" -eq "2" ]]; then
      srccenter="-21.975 0 148.82"
    elif [[ "$2" -eq "3" ]]; then 
      #srccenter="-8.875 0 148.82"
      srccenter="-8.875 0 147.232"
    elif [[ "$2" -eq "4" ]]; then 
      srccenter="-8.875 0 147.232"
    fi
  elif  [[ "$srcori" == "Up" ]]; then
    if [[ "$2" -eq "2" ]]; then
      srccenter="-21.975 0 149.63"
    elif [[ "$2" -eq "3" ]]; then 
      #srccenter="-8.875 0 149.63"
      srccenter="-8.875 0 148.042"
    elif [[ "$2" -eq "4" ]]; then 
      srccenter="-8.875 0 148.042"
    fi
  fi
  ;;
"3")
  srctype='Circle'
  srcradius='2.5'
  srcori=`echo $4 | awk -F_ '{print $2}'`
  if [[ "$srcori" == "Down" ]]; then
    if [[ "$2" -eq "2" ]]; then
      srccenter="250.42 0 0"
    elif [[ "$2" -eq "3" ]]; then 
      srccenter="250.42 0 0"
    elif [[ "$2" -eq "4" ]]; then 
      srccenter="250.42 0 0"
    fi
  elif  [[ "$srcori" == "Up" ]]; then
    if [[ "$2" -eq "2" ]]; then
      srccenter="251.23 0 0"
    elif [[ "$2" -eq "3" ]]; then 
      srccenter="251.23 0 0"
    elif [[ "$2" -eq "4" ]]; then 
      srccenter="251.23 0 0"
    fi
  fi
  ;;
#"2")
#  srctype='point'
#  if [[ "$2" -eq "2" ]]; then
#    srcpos="-21.975 0 149.622"
#  elif [[ "$2" -eq "3" ]]; then 
#    srcpos="-8.875 0 149.622"
#  fi
#  ;;
#"3")
#  srctype='point'
#  srcpos="251.222 0 0"
#  ;;
"4")
  srctype='Circle'
  srcradius='2.5'
  srcori=`echo $4 | awk -F_ '{print $2}'`
  if [[ "$srcori" == "Down" ]]; then
    if [[ "$2" -eq "2" ]]; then
      srccenter="210.025 -139.7 -148.82"
    elif [[ "$2" -eq "3" ]]; then 
      srccenter="223.125 -139.7 -148.82"
    elif [[ "$2" -eq "4" ]]; then 
      srccenter="223.125 -139.7 -148.82"
    fi
  elif [[ "$srcori" == "Up" ]]; then
    if [[ "$2" -eq "2" ]]; then
      srccenter="210.025 -139.7 -149.63"
    elif [[ "$2" -eq "3" ]]; then 
      srccenter="223.125 -139.7 -149.63"
    elif [[ "$2" -eq "4" ]]; then 
      srccenter="223.125 -139.7 -149.63"
    fi
  fi
  ;;
"M17.3")
  srctype='Para'
  case "$5" in 
  "1")
    srccenter="-120.803 -142.326 -57.4"
    srchalflength="120 10.0744 95"
    ;;
  "2")
    srccenter="-90.8033 0 -87.6308"
    srchalflength="90 120 19.6373"
    ;;
  "3")
    srccenter="14.2983 0 -57.4"
    srchalflength="15.1017 120 95"
    ;;
  "4")
    srccenter="-90.8033 0 -129.834"
    srchalflength="90 120 22.5659"
    ;;
  "5")
    srccenter="-120.803 137.574 -57.4"
    srchalflength="120 14.8259 95"
    ;;
  esac
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  ;;
"M17.2")
  srctype='Para'
  case "$5" in 
  "1x2")
    srccenter="-64.475 0 -102.4" 
    srchalflength="97.5 110 50" 
    ;;
  "3")
    srccenter="-116.975 90.8 17.6" 
    srchalflength="95 40 70" 
    ;;
  "4")
    srccenter="-126.975 -80.8 27.6" 
    srchalflength="105 30 80" 
    ;;
  "5")
    srccenter="58.025 0 -77.4" 
    srchalflength="25 105 75" 
    ;;
  esac
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  ;;
"M17.1")
  case "$5" in 
  "1x2")
    srctype='Cylinder'
    srccenter="-82.4375 0 0"
    srcdimensions="50.801 82.1576 107.838"
    srcradius=`echo $srcdimensions | awk '{print $2}'`
    srchalfz=`echo $srcdimensions | awk '{print $3}'`
    # Hard coded to: (commented out at 140507-1440)
    # 1. rotate 90 deg about y-axis (so that tube lies along x-axis)
    # 2. confine to volume "M17.1_1x2"
    ;;
  "3")
    srctype='Para'
    srccenter="-82.4375 0 -128.222"
    srchalflength="107.838 76.2 24.1778"
    srchalfx=`echo $srchalflength | awk '{print $1}'`
    srchalfy=`echo $srchalflength | awk '{print $2}'`
    srchalfz=`echo $srchalflength | awk '{print $3}'`
    ;;
  esac
  ;;
"PeBottle")  
  # hardcoded for bottle bottom thickness = 2 mm
  srctype='Cylinder'
  srcradius="23.1"
  srchalfz=`echo $4 | awk -F_ '{print ($3-2)*0.5}'`
  srcliquid=`echo $4 | awk -F_ '{print $2}'`
  case $srcliquid in
    "LL134SiWafer")
      # hardcoded for liquid level = 74 mm
      if [[ "$5" -eq "1" ]]; then
        srccenter="3.125 -25.1 5.6"
      elif [[ "$5" -eq "2" ]]; then
        srccenter="3.125 25.1 5.6"
      elif [[ "$5" -eq "3" ]]; then
        srccenter="-47.075 69.6 -36.4"
      elif [[ "$5" -eq "4" ]]; then
        srccenter="-47.075 -69.6 -36.4"
      fi
    ;;
    "LL134SiWaferAlt")
      # hardcoded for liquid level = 74 mm
      if [[ "$5" -eq "1" ]]; then
        srccenter="3.125 -25.1 -2.4"
      elif [[ "$5" -eq "2" ]]; then
        srccenter="3.125 25.1 -2.4"
      elif [[ "$5" -eq "3" ]]; then
        srccenter="53.325 25.1 -2.4"
      elif [[ "$5" -eq "4" ]]; then
        srccenter="53.325 -25.1 -2.4"
      fi
    ;;
    *)
    if [[ "$2" -eq "2" ]]; then
      srccenter="3.126 0 `echo $srchalfz | awk '{print $1-47.5}'`"  # for bottle at mid-Z
      #srccenter="3.126 0 `echo $srchalfz | awk '{print $1-47.5+24.1}'`"  # for bottle on 5-inch stand
    elif [[ "$2" -eq "3" ]]; then 
      srccenter="16.226 0 `echo $srchalfz | awk '{print $1-47.5}'`" # for bottle at mid-Z
      #srccenter="16.226 0 `echo $srchalfz | awk '{print $1-47.5+25.6875}'`" # for bottle on 5-inch stand
    elif [[ "$2" -eq "4" ]]; then 
      srccenter="16.226 0 `echo $srchalfz | awk '{print $1-47.5}'`" # for bottle at mid-Z
      #srccenter="16.226 0 `echo $srchalfz | awk '{print $1-47.5+25.6875}'`" # for bottle on 5-inch stand
    fi
    ;;
  esac
  ;;
"Exo200")
  srctype='Sphere'
  exosrcloc=`echo $4 | awk -F_ '{print $2}'`
  exosrcori=`echo $4 | awk -F_ '{print $3}'`
  echo $exosrcloc
  if [[ "$2" -eq "2" ]]; then
    if [[ "$exosrcloc" == "Remote1" ]]; then
      case "$exosrcori" in 
      "XP") srccenter="-20.6161 -139.7 -150.352" ;;
      "XN") srccenter="-23.3339 -139.7 -150.352" ;;
      "YP") srccenter="-21.975 -138.341 -150.352" ;;
      "YN") srccenter="-21.975 -141.059 -150.352" ;;
      esac
    elif [[ "$exosrcloc" == "Remote2" ]]; then 
      case "$exosrcori" in 
      "XP") srccenter="211.384 -139.7 -150.352" ;;
      "XN") srccenter="208.666 -139.7 -150.352" ;;
      "YP") srccenter="210.025 -138.341 -150.352" ;;
      "YN") srccenter="210.025 -141.059 -150.352" ;;
      esac
    fi
  elif [[ "$2" -eq "3" ]]; then
    if [[ "$exosrcloc" == "Remote1" ]]; then
      case "$exosrcori" in 
      "XP") srccenter="-7.5161 -139.7 -150.352" ;;
      "XN") srccenter="-10.2339 -139.7 -150.352" ;;
      "YP") srccenter="-8.875 -138.341 -150.352" ;;
      "YN") srccenter="-8.875 -141.059 -150.352" ;;
      esac
    elif [[ "$exosrcloc" == "Remote2" ]]; then 
      case "$exosrcori" in 
      "XP") srccenter="224.484 -139.7 -150.352" ;;
      "XN") srccenter="221.766 -139.7 -150.352" ;;
      "YP") srccenter="223.125 -138.341 -150.352" ;;
      "YN") srccenter="223.125 -141.059 -150.352" ;;
      esac
    fi
  fi
  srcradius="0.35"
  ;;
"GerdaD6")
  srctype='Para'
  srccenter='-11.975 1.5 0'
  srchalflength='10 100 100'
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  srcvol='GerdaD6Block'
  ;;
"XLPE")
  srctype='Para'
  case "$5" in 
  "1")
    srccenter='-101.6 0 110'
    srchalflength='152.4 152.4 50'
    ;;
  "2")
    srccenter='-101.6 0 80'
    srchalflength='152.4 152.4 50'
    ;;
  "3")
    srccenter='-101.6 0 45'
    srchalflength='152.4 152.4 55'
    ;;
  "4")
    srccenter='-101.6 -76.2 -35'
    srchalflength='152.4 76.2 125'
    ;;
  "5")
    srccenter='127 0 0'
    srchalflength='76.2 152.4 152.4'
    ;;
  esac
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  srcvol=${4}_${5}
  ;;
"EndCap")
  srctype='Cylinder'
  srccenter='-122.625 0 0'
  srcradius='47.625'
  srchalfz='113.75'
  srcvol='EndCap'
  ;;
"M16.1")
  srctype='Para'
  case "$5" in 
  "1")
    srccenter='-69.175 0 -88.1'
    srchalflength='76.2 76.2 13.5'
    ;;
  "2")
    srccenter='-98.175 -64.3 1.6'
    srchalflength='76.2 13.5 76.2'
    ;;
  "3")
    srccenter='-98.175 64.3 1.6'
    srchalflength='76.2 13.5 76.2'
    ;;
  "4")
    srccenter='-7.475 0 1.6'
    srchalflength='14.5 76.2 76.2'
    ;;
  "5")
    srccenter='-69.175 0 92.8'
    srchalflength='76.2 76.2 15'
    ;;
  esac
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  #srcvol=${4}_${5}
  ;;

"M16.3")
  srctype='Para'
  case "$5" in 
  "1")
    srccenter='-52.075 0 -111.412'
    srchalflength='76.2 76.2 14'
    ;;
  "2")
    srccenter='-85.075 -62.625 -21.2125'
    srchalflength='76.2 15 76.2'
    ;;
  "3")
    srccenter='-85.075 63.125 -21.2125'
    srchalflength='76.2 15.5 76.2'
    ;;
  "4")
    srccenter='7.625 0 -21.2125'
    srchalflength='16.5 76.2 76.2'
    ;;
  "5")
    srccenter='-52.075 0 69.9875'
    srchalflength='76.2 76.2 15'
    ;;
  esac
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  #srcvol=${4}_${5}
  ;;
"M16.2")
  srctype='Para'
  case "$5" in 
  "1")
    srccenter='-76.675 0 -89.1'
    srchalflength='76.2 76.2 12.5'
    ;;
  "2")
    srccenter='-98.175 -63.7 -0.4'
    srchalflength='76.2 12.5 76.2'
    ;;
  "3")
    srccenter='-98.175 63.7 -0.4'
    srchalflength='76.2 12.5 76.2'
    ;;
  "4")
    srccenter='-11.225 0 -0.4'
    srchalflength='10.75 76.2 76.2'
    ;;
  "5")
    srccenter='-76.675 0 88.3'
    srchalflength='76.2 76.2 12.5'
    ;;
  esac
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  #srcvol=${4}_${5}
  ;;

"WippSalt")
  srctype='Para'
  sample=`echo $4 | awk -F_ '{print $2}'`
  case "$sample" in 
  "1")
    srccenter='-3.875 0 0' #mm 
    srchalflength='5 37.5 35' #mm
    ;;
  "2")
    srccenter='-3.875 0 0' #mm 
    srchalflength='5 36 55' #mm
    ;;
  "3")
    srccenter='-1.375 0 0' #mm 
    srchalflength='7.5 45 35' #mm
    ;;
  "4")
    srccenter='-2.975 0 0' #mm 
    srchalflength='5.9 35.45 20.9' #mm
    ;;
  "5")
    srccenter='-6.875 0 0' #mm 
    srchalflength='2 55 37' #mm
    ;;
  "16")
    srccenter='-8.025 0 0' #mm 
    srchalflength='0.85 34.815 34.235' #mm
    ;;
  esac
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  #srcvol=${4}_${5}
  ;;
"WippSalt5Detailed")
  srctype='Para'
  sample=`echo $4 | awk -F_ '{print $2}'`
  case "$sample" in 
  "A")
    srccenter='-7.5648 0 0' #mm 
    srchalflength='0.2815 54.8857 36.8857' #mm
    ;;
  "B")
    srccenter='-8.4792 0 0' #mm 
    srchalflength='0.2815 54.8857 36.8857' #mm
    ;;
  esac
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  ;;

"Ceiling")
  # For Wipp salt gamma emanation study
  srctype='Para'
  # hardcoded for 86 cm salt
  srccenter='0 0 1963.4' #mm 1533.4 + (860 / 2)
  srchalflength='1500 1500 43' #mm
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  #srcvol=${4}_${5}
  ;;

"CeilingSurface")
  # For Wipp salt gamma emanation study
  srctype='Para'
  # hardcoded for salt surface (1um into surface)
  srccenter='0 0 1533.4001' #mm 1533.4 + (0.001 / 2)
  srchalflength='1500 1500 0.0001' #mm
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  #srcvol=${4}_${5}
  ;;

"PbShielding")
  srctype='Para'
  srccenter='0 0 0' #mm 1533.4 + (860 / 2)
  #srchalflength='635 533.4 533.4' #mm
  srchalflength='508 406.4 406.4' #mm
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  srcvol="OuterShielding"
  ;;

"InnerShielding")
  srctype='Para'
  srccenter='0 0 0' #mm 
  srchalflength='304.8 203.2 203.2' #mm
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  srcvol="InnerShielding"
  ;;

"Internals")
  srctype='Para'
  case "$5" in
  "Electronics")
    srctype='point'
    #srcpos='-154.875 0 5'    #wrong
    srcpos='-120.875 0 -30'
    ;;
  "Neck")
    srccenter='-228.6 0 -101.6' #mm 
    srchalflength='76.2 25.4 101.6' #mm
    srcvol=$5
    ;;
  "IrShieldMylar")
    srccenter='-15.871 0 0' #mm 
    srchalflength='0.01 50.8 50.8' #mm
    srcvol=$5
    ;;
  "IrShieldKapton")
    srccenter='-15.864 0 0' #mm 
    srchalflength='0.01 50.8 50.8' #mm
    srcvol=$5
    ;;
  "EndCapScrew")
    srccenter='-164 0 0' #mm 
    srchalflength='2 50.8 50.8' #mm
    srcvol=$5
    ;;
  *)
    srccenter='-152.4 0 0' #mm 
    srchalflength='152.4 50.8 50.8' #mm
    srcvol=$5
    ;;
  esac
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  ;;

"R-028")
  srctype='Para'
  srccenter='-0.105 0 0' #mm 
  srchalflength='8.77 75.115 75.115' #mm
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  srcvol="R-028"
  ;;

"R-029")
  srctype='Para'
  srccenter='0.775 0 0' #mm 
  srchalflength='22.75 66.7 42.7' #mm
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  srcvol="R-029"
  ;;

"R-030")
  srctype='Para'
  srccenter='0 0 0' #mm 
  srchalflength='200 200 200' #mm
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  srcvol="R-030"
  ;;
 
"WmCu")
  srctype='Para'
  srccenter='0 0 0' #mm 
  srchalflength='200 200 200' #mm
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  srcvol="WmCu"
  ;;

"WmCu2")
  srctype='Para'
  srccenter='0 0 0' #mm 
  srchalflength='200 200 200' #mm
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  srcvol="WmCu2"
  ;;

"M16.4")
  srctype='Para'
  srccenter='0 0 0' #mm 
  #srchalflength='200 200 200' #mm
  #srchalfx=`echo $srchalflength | awk '{print $1}'`
  #srchalfy=`echo $srchalflength | awk '{print $2}'`
  #srchalfz=`echo $srchalflength | awk '{print $3}'`
  #srcvol="M16.4"
  srchalflength='304.8 203.2 203.2' #mm
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  srcvol="InnerShielding"
  ;;

"Front")
  srctype='point'
  # 5 mm in front of Ge2
  srcpos="-16.975 0 0"
  ;;

"CalibSilica")
  srctype='Para'
  srccenter='0 0 0' #mm 
  srchalflength='50 50 50' #mm
  srchalfx=`echo $srchalflength | awk '{print $1}'`
  srchalfy=`echo $srchalflength | awk '{print $2}'`
  srchalfz=`echo $srchalflength | awk '{print $3}'`
  srcvol="CalibSilica"
  ;;

"Front2")
  srctype='point'
  # 132 mm in front of Ge2 (132-21.975 mm)
  srcpos="110.025 0 0"
  ;;

esac


# ======================================================================

# Build detector selection command
if [[ $2 == "2" ]]; then
  detselect="/gesim/detector/selectDetector $2\n\
/gesim/analysis/selectDetector $2\n\
/gesim/source/setSourcePosition $4\n\
/gesim/detector/setDeadLayerTweak 0.523 mm\n"
#/gesim/detector/setMisalignment 10.3188 mm\n"
elif [[ $2 == "3" ]]; then
  detselect="/gesim/detector/selectDetector $2\n\
/gesim/analysis/selectDetector $2\n\
/gesim/source/setSourcePosition $4\n"
elif [[ $2 == "4" ]]; then
  detselect="/gesim/detector/selectDetector 3\n\
/gesim/analysis/selectDetector $2\n\
/gesim/source/setSourcePosition $4\n"
fi

# Build event generation command
atomA=`echo $3 | sed 's/^[A-Za-z]*//'`
atomZ=`echo $3 | sed 's/[0-9]*$//' | python atoms.py`
evtgen="/histo/fileName $1 \n\
/random/setSeeds $seed 98765 \n\
/gps/ion $atomZ $atomA 0 0\n"

# Build source type command
if [[ $srctype == "point" ]]; then
  srcselect="/gps/particle ion\n\
/gps/energy 0 MeV\n\
/gps/ang/type iso\n\
/gps/position $srcpos mm\n"
elif [[ $srctype == "Para" ]]; then
  srcselect="/gps/particle ion\n\
/gps/energy 0 MeV\n\
/gps/ang/type iso\n\
/gps/pos/type Volume \n\
/gps/pos/shape Para \n\
/gps/pos/centre $srccenter mm \n\
/gps/pos/halfx $srchalfx mm \n\
/gps/pos/halfy $srchalfy mm \n\
/gps/pos/halfz $srchalfz mm \n"
elif [[ $srctype == "Cylinder" ]]; then
  srcselect="/gps/particle ion\n\
/gps/energy 0 MeV\n\
/gps/ang/type iso\n\
/gps/pos/type Volume \n\
/gps/pos/shape Cylinder \n\
/gps/pos/centre $srccenter mm \n\
/gps/pos/radius $srcradius mm \n\
/gps/pos/halfz $srchalfz mm \n"
#/gps/pos/rot1 0 1 0\n\
#/gps/pos/rot2 0 0 1\n"
#/gps/pos/confine M17.1_1x2\n"
elif [[ $srctype == "Sphere" ]]; then
  srcselect="/gps/particle ion\n\
/gps/energy 0 MeV\n\
/gps/ang/type iso\n\
/gps/pos/type Volume \n\
/gps/pos/shape Sphere \n\
/gps/pos/centre $srccenter mm \n\
/gps/pos/radius $srcradius mm \n"
elif [[ $srctype == "Circle" ]]; then
  srcselect="/gps/particle ion\n\
/gps/energy 0 MeV\n\
/gps/ang/type iso\n\
/gps/pos/type Plane \n\
/gps/pos/shape Circle \n\
/gps/pos/centre $srccenter mm \n\
/gps/pos/radius $srcradius mm \n"
fi

if [ -n "$srcvol" ]; then
  srcselect="$srcselect/gps/pos/confine $srcvol\n"
fi

# Build nevt command
nevt='/run/beamOn '"$6"'\n'

# ======================================================================

# Substitute {*} with actual commands
cmds='detselect evtgen srcselect nevt'
cp scripts/template.in $1.in
for cmd in $cmds; do
  #echo $cmd : ${!cmd}
  sed -i "s:{$cmd}:#BEGIN $cmd\n${!cmd}#END $cmd\n:" $1.in
done

# Run GeSim
./GeSim $1.in 

echo "$1 end time  : `date`"

################################################################################

#sed 's:{DETSELECT}:#BEGIN DETSELECT\n/gesim/detector/selectDetector '"$2"'\n/gesim/analysis/selectDetector '"$2"'\n/gesim/source/setSourcePosition '"$4"'\n#END DETSELECT\n:' scripts/template.in |
#sed 's:{EVTGEN}:#BEGIN EVTGEN\n/histo/fileName '"$1"'\n/random/setSeeds '"$seed"' 98765\n/gps/position '"$srcpos"' mm\n/gps/ion '"$atomZ"' '"$atomA"' 0 0\n#END EVTGEN\n:' | 
#sed 's:{DETSELECT}:#BEGIN DETSELECT\n'"$detselect"'#END DETSELECT\n:' scripts/template.in |
#sed 's:{EVTGEN}:#BEGIN EVTGEN\n'"$evtgen"'#END EVTGEN\n:' | 
#sed 's:{SRCTYPE}:#BEGIN SRCTYPE\n'"$srctype"'#END SRCTYPE\n:' |
#sed 's:{NEVT}:#BEGIN NEVT\n/run/beamOn '"$5"'\n#END NEVT\n:' > $1.in

