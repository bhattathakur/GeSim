#include "TFile.h"
#include "TTree.h"
#include "TH1D.h"

void simtohist(string det, char * filename, char * outfile = "out.root"){
  TFile f(filename,"read");
  TTree * tT1 = (TTree *) f.Get("tT1");
  TFile fout(outfile,"recreate");
  TH1D * hSpec = new TH1D("hSpec","Simulated spectrum",8192,-0.5,8191.5);
  TH1D * hSpecWide = new TH1D("hSpecWide","Simulated spectrum (Wide) in MeV",1000,0,100);
  if(det == "Ge2"){
    tT1->Draw("(1000*Energy+1.128)/0.3485 >> hSpec");
    tT1->Draw("Energy >> hSpecWide");
  }else if(det == "Ge3"){ 
    tT1->Draw("(1000*Energy-0.1987)/0.3483 >> hSpec");
    tT1->Draw("Energy >> hSpecWide");
  }else if(det == "Ge4"){ 
    tT1->Draw("(1000*Energy+0.1268)/0.2787 >> hSpec");
    tT1->Draw("Energy >> hSpecWide");
  }
  fout.Write();
}
