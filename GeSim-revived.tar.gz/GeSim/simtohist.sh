pushd $1;
rm -f combinedraw.root all.root
hadd combinedraw.root *.root
root -l -q simtohist.C\(\"$2\",\"combinedraw.root\",\"all.root\"\)
popd

