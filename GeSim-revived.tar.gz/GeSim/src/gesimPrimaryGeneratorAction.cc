#include "G4Event.hh"
#include "G4GeneralParticleSource.hh"
#include "Randomize.hh"

#include "gesimPrimaryGeneratorAction.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

gesimPrimaryGeneratorAction::gesimPrimaryGeneratorAction()
{
  fParticleGun = new G4GeneralParticleSource ();
}

gesimPrimaryGeneratorAction::~gesimPrimaryGeneratorAction()
{
  delete fParticleGun;
}

void gesimPrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{
  //const G4long * table_entry = CLHEP::HepRandom::getTheSeeds();
  //G4cout << "PGA: Random Seed: " << *table_entry << ", " << *(table_entry+1) << G4endl;
  //G4cout << "PGA: Random Seed Index: " << CLHEP::HepRandom::getTheSeed() << G4endl;
  fParticleGun->GeneratePrimaryVertex(anEvent);
}



